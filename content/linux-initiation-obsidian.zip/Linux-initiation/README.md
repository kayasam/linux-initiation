# Linux — Initiation

Ouvrez ce dossier comme coffre dans Obsidian. Les cours se trouvent dans `cours/` et les exercices dans `tp/`. Ouvrez les fichiers HTML dans votre navigateur pour les versions interactives.

- [Comprendre Linux](cours/01-comprendre-linux.md)
- [Installer la machine virtuelle](cours/02-installer-la-vm.md)
- [L'interface graphique](cours/03-interface-graphique.md)
- [Le terminal](cours/04-le-terminal.md)
- [Fichiers et répertoires](cours/05-fichiers-et-repertoires.md)
- [L'arborescence Linux](cours/06-arborescence-linux.md)
- [Utilisateurs et permissions](cours/07-utilisateurs-et-permissions.md)
- [Gestion des paquets](cours/08-gestion-des-paquets.md)
- [Redirections et tubes](cours/09-redirections-et-tubes.md)
- [Réseau et services](cours/10-reseau-et-services.md)