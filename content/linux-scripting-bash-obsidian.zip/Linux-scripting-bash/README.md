# Scripting Bash

Ouvrez ce dossier dans Obsidian. Les six cours sont dans `cours/` et les exercices dans `tp/`. Les versions HTML sont autonomes et se consultent dans un navigateur.
