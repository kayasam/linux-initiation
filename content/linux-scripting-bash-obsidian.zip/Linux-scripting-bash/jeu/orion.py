#!/usr/bin/env python3
"""Orion Académie: a standard-library terminal adventure backed by a real Bash."""
from __future__ import annotations
import argparse
import contextlib
import datetime
import json
import os
from pathlib import Path
import select
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import textwrap
import time

VERSION = '1.0.0'
HERE = Path(__file__).resolve().parent
VARIABLES = ['station', 'pilote', 'carburant', 'reserve', 'total', 'message', 'NOM_STATION', 'secret', 'essais']
ACTS = [
    ('01', 'Capsule de secours', 'Les lumières clignotent. BIP-42 te prend pour le livreur de pizzas.', 'Cadet des étoiles'),
    ('02', 'Radio et boîte noire', 'Une radio grésille : « Orion… chocolat… urgence… »', 'Voix du vide'),
    ('03', 'Réservoir des variables', 'BIP-42 a rangé le carburant dans une boîte appelée « bidule ».', 'Maître des réserves'),
    ('04', 'Atelier des robots', 'Trois robots attendent leurs instructions. Un quatrième fait déjà une pause.', 'Mécano cosmique'),
    ('05', 'Sas des conditions', 'Le sas ne s’ouvre qu’aux humains logiques. BIP-42 est resté dehors.', 'Gardien du sas'),
    ('06', 'Hangar des boucles', 'Six drones demandent la même chose. Le chef demande une boucle.', 'Chef des drones'),
    ('07', 'Observatoire des données', 'Le stock contient trente boulons et beaucoup trop de chaussettes.', 'Cartographe stellaire'),
    ('08', 'Finale : le code chocolat', 'Le distributeur exige un jeu complet. BIP-42 exige les droits d’auteur.', 'Commandant d’Orion'),
]
ART = r'''
             .                    *                  .
      *              .---.              .
                 .--'     '--.                 *
       .       _/   ORION     \_      .
           ===[=== ACADEMIE ===]===
               \_           _/                .
         .       '--.   .--'         *
                     '-'                   .
     UNE STATION A SAUVER. UN ROBOT A SUPPORTER.
'''
ROBOT = r'''
       .-----.
       | o o |   BIP-42
       |  ^  |   service technique / mauvaise foi
      /|-----|\
     / |_____| \
        /   \
'''
SCENES = [
    r'      /---\       CAPSULE\n  ___/_____\___   ARRIVEE\n      /   \\',
    r'       \\ | /      RADIO\n     --- (O) ---   SIGNAL SOS\n        / | \\',
    r'     .------.     RESERVES\n     | #### |     CARBURANT\n     |______|',
    r'     [o_o]--.     ATELIER\n     /|___|  \\    ROBOTS\n       / \\',
    r'     |[====]|     SAS\n     |  ||  |     CONTROLE\n     |__||__|',
    r'      --[o]--     HANGAR\n       / | \\      DRONES\n      *  *  *',
    r'     *   .---.    OBSERVATOIRE\n       _/____/    DONNEES\n          ||',
    r'       ( (        FINALE\n      .---.       CHOCOLAT\n      |___|)',
]


class BashSession:
    """Persistent Bash; commands use a private pipe, terminal input stays usable."""
    def __init__(self, workspace, cwd=None, variables=None, headless=False, exported=None):
        self.workspace = Path(workspace).resolve()
        self.cwd = Path(cwd or workspace).resolve()
        self.variables = variables or {}
        self.exported = set(exported or [])
        self.headless = headless
        self.temp = tempfile.TemporaryDirectory(prefix='orion-shell-')
        self.process = None
        self.last_code = 0
        self.start()

    def start(self):
        cmd_read, cmd_write = os.pipe()
        ack_read, ack_write = os.pipe()
        dispatcher = f'''
shopt -s expand_aliases
trap ':' INT
__orion_last=0
__orion_restore() {{ return "$1"; }}
while IFS= read -r __orion_file <&{cmd_read}; do
    __orion_restore "$__orion_last"
    builtin source "$__orion_file"
    __orion_last=$?
    builtin printf '%s\\n' "$__orion_last" >&{ack_write}
done
'''
        self.process = subprocess.Popen(['bash', '--noprofile', '--norc', '-c', dispatcher],
            cwd=self.cwd, stdin=subprocess.DEVNULL if self.headless else None,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            pass_fds=(cmd_read, ack_write), start_new_session=True, env={**os.environ, 'ORION_ATELIER': str(self.workspace)})
        os.close(cmd_read); os.close(ack_write)
        self.commands = os.fdopen(cmd_write, 'w', buffering=1)
        self.ack = ack_read
        self.execute('\n'.join(('export ' if key in self.exported else '') + f'{key}={shlex.quote(value)}' for key, value in self.variables.items() if key in VARIABLES), display=False)

    def execute(self, code, display=True, timeout=None):
        path = Path(self.temp.name) / 'commande.sh'
        path.write_text(code + '\n', encoding='utf-8')
        syntax = subprocess.run(['bash', '-n', str(path)], capture_output=True, text=True)
        if syntax.returncode:
            if display: print(syntax.stderr, end='')
            self.execute(f'__orion_restore {syntax.returncode}', display=False)
            return syntax.returncode, syntax.stderr
        if self.process.poll() is not None:
            raise RuntimeError('Le shell est fermé. Reprends la partie pour en ouvrir un nouveau.')
        self.commands.write(str(path) + '\n')
        output, ack = bytearray(), bytearray()
        start = time.monotonic()
        interrupted = False
        while b'\n' not in ack:
            try:
                if timeout and time.monotonic() - start > timeout:
                    raise TimeoutError('Commande trop longue')
                ready, _, _ = select.select([self.process.stdout, self.ack], [], [], .1)
                for fd in ready:
                    if fd == self.ack:
                        chunk = os.read(self.ack, 128)
                        if not chunk: raise RuntimeError('Le shell est fermé (exit ou commande interrompue).')
                        ack.extend(chunk)
                    else:
                        chunk = os.read(self.process.stdout.fileno(), 8192)
                        if not chunk: raise RuntimeError('Le shell est fermé (exit ou commande interrompue).')
                        output.extend(chunk)
                        if display:
                            sys.stdout.write(chunk.decode('utf-8', errors='replace')); sys.stdout.flush()
                        if len(output) > 1024 * 1024: raise TimeoutError('Sortie trop longue : utilise un filtre ou head.')
            except KeyboardInterrupt:
                if interrupted: raise
                interrupted = True
                os.killpg(self.process.pid, signal.SIGINT)
                print('\n[BIP-42] Commande interrompue. Le chocolat peut attendre.')
                timeout = time.monotonic() - start + 3
        while select.select([self.process.stdout], [], [], .02)[0]:
            chunk = os.read(self.process.stdout.fileno(), 8192)
            if not chunk: break
            output.extend(chunk)
            if display:
                sys.stdout.write(chunk.decode('utf-8', errors='replace')); sys.stdout.flush()
        self.last_code = int(ack.split(b'\n', 1)[0])
        return self.last_code, output.decode('utf-8', errors='replace')

    def snapshot(self):
        saved_code = self.last_code
        target = Path(self.temp.name) / 'etat.bin'
        fields = ['"$PWD"'] + ['"${' + key + '-}"' for key in VARIABLES]
        snapshot = "builtin printf '%s\\0' " + ' '.join(fields) + ' > ' + shlex.quote(str(target))
        snapshot += '\nfor __orion_name in ' + ' '.join(VARIABLES) + '; do\n'
        snapshot += '''    __orion_declaration=$(builtin declare -p "$__orion_name" 2>/dev/null)
    if [[ "$__orion_declaration" == 'declare -x '* ]]; then
        builtin printf '1\\0'
    else
        builtin printf '0\\0'
    fi
done >> ''' + shlex.quote(str(target))
        self.execute(snapshot, display=False)
        values = target.read_bytes().decode('utf-8', errors='replace').split('\0')
        self.cwd = Path(values[0])
        self.variables = dict(zip(VARIABLES, values[1:]))
        self.exported = {key for key, flag in zip(VARIABLES, values[1+len(VARIABLES):]) if flag == '1'}
        self.execute(f'__orion_last={saved_code}', display=False)
        # The dispatcher itself captures the assignment's 0; restore via a return.
        self.execute(f'__orion_restore {saved_code}', display=False)
        return str(self.cwd), self.variables

    def close(self):
        if self.process is not None:
            with contextlib.suppress(ProcessLookupError): os.killpg(self.process.pid, signal.SIGTERM)
            try: self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                with contextlib.suppress(ProcessLookupError): os.killpg(self.process.pid, signal.SIGKILL)
                self.process.wait()
            self.commands.close(); os.close(self.ack); self.process.stdout.close()
            self.process = None
        self.temp.cleanup()


def load_missions():
    data = json.loads((HERE / 'missions.json').read_text(encoding='utf-8'))
    assert len(data) == 48 and len({m['id'] for m in data}) == 48
    return data


def seed(workspace):
    files = {
        'radio/bruit.txt': 'INFO : antenne froide\nSOS : Orion demande du chocolat\nINFO : meteorite evitee\nSOS : BIP-42 a mange le manuel\n',
        'donnees/stock.csv': 'objet;categorie;quantite;prix\nboulon;atelier;30;2\nchaussette;cabine;12;3\nchocolat;cuisine;4;5\nantenne;radio;2;40\n',
        'donnees/equipage.txt': 'Mila Vega\nNoe\nSami\n',
        'messages/robot.txt': 'ROBOT : Je suis parfaitement operationnel. Presque.\n',
        'messages/accueil.txt': 'Bienvenue sur Orion\n',
        'messages/journal radio.txt': 'La radio fonctionne\n',
        'atelier/drone-panne.sh': '#!/bin/bash\necho "Drone repare\n',
        'donnees/billet equipe.txt': 'ORION-OK\n',
        'donnees/faux-billet.txt': 'PAS-ORION-OK\n',
    }
    for folder in ['capsule', 'radio', 'donnees', 'messages', 'atelier', 'rapports', 'sauvegardes', 'finale']:
        (workspace / folder).mkdir(parents=True, exist_ok=True)
    for name, body in files.items(): (workspace / name).write_text(body, encoding='utf-8')
    (workspace / 'messages/faux.txt').mkdir()


def check_mission(mission, workspace, session, last_output):
    """Check results rather than impose one exact command spelling."""
    cwd, variables = session.snapshot()
    failures = []
    for check in mission['checks']:
        kind = check['type']; ok = False
        path = workspace / check.get('path', '.')
        try:
            if kind == 'cwd': ok = Path(cwd) == path.resolve()
            elif kind == 'dir': ok = path.is_dir()
            elif kind == 'file': ok = path.is_file()
            elif kind == 'text': ok = path.read_text(encoding='utf-8') == check['value']
            elif kind == 'contains': ok = check['value'] in path.read_text(encoding='utf-8')
            elif kind == 'output': ok = check['value'] in last_output
            elif kind == 'output_absent': ok = check['value'] not in last_output
            elif kind == 'variable': ok = variables.get(check['name']) == check['value']
            elif kind == 'executable': ok = path.is_file() and os.access(path, os.X_OK)
            elif kind == 'same': ok = path.read_bytes() == (workspace / check['other']).read_bytes()
            elif kind == 'script':
                # Run checks on a copy: checking a game must not add real scores.
                with tempfile.TemporaryDirectory(prefix='orion-controle-') as temp:
                    lab = Path(temp) / 'atelier'
                    shutil.copytree(workspace, lab, symlinks=True)
                    for missing in check.get('without', []):
                        target = lab / missing
                        if target.is_relative_to(lab) and target.is_file(): target.unlink()
                    for name, content in check.get('fixtures', {}).items():
                        target = lab / name
                        if target.is_relative_to(lab): target.write_text(content, encoding='utf-8')
                    program = lab / check['path']
                    command = [str(program)] if check.get('direct') else ['bash', str(program)]
                    stdin = check.get('input', '')
                    if 'random_seed' in check:
                        random_seed = int(check['random_seed'])
                        secret = subprocess.check_output(['bash', '-c', f'RANDOM={random_seed}; echo "$((RANDOM % 9 + 1))"'], text=True).strip()
                        command = ['bash', '-c', f'__orion_program=$1; shift; RANDOM={random_seed}; source "$__orion_program"', str(program), str(program)]
                        stdin = secret + '\n'
                    process = subprocess.Popen(command + check.get('args', []), cwd=lab / check.get('cwd', '.'),
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                        start_new_session=True, env={**os.environ, 'ORION_ATELIER': str(lab)})
                    try:
                        stdout, stderr = process.communicate(stdin, timeout=3)
                    except subprocess.TimeoutExpired:
                        with contextlib.suppress(ProcessLookupError): os.killpg(process.pid, signal.SIGKILL)
                        process.communicate()
                        raise
                    result = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
                    ok = result.returncode == check.get('code', 0) and all(value in result.stdout + result.stderr for value in check.get('output', []))
                    for name, value in check.get('after', {}).items():
                        ok = ok and (lab / name).read_text(encoding='utf-8') == value
            else: raise ValueError('Contrôle inconnu : ' + kind)
        except (OSError, UnicodeError, subprocess.TimeoutExpired): ok = False
        if not ok: failures.append(check['label'])
    return failures


class Game:
    def __init__(self, root, new=False, color=True):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.profile = self.root / 'sauvegarde.json'
        self.color = color and sys.stdout.isatty() and not os.environ.get('NO_COLOR') and os.environ.get('TERM') != 'dumb'
        self.missions = load_missions()
        self.history = []
        if self.profile.exists() and not new:
            self.state = json.loads(self.profile.read_text(encoding='utf-8'))
            if not isinstance(self.state.get('index'), int) or not 0 <= self.state['index'] < 48 or not isinstance(self.state.get('completed'), list):
                raise ValueError('Sauvegarde invalide. --nouvelle crée une autre partie sans effacer les fichiers.')
            self.workspace = Path(self.state['workspace']).resolve()
            if self.workspace.parent != self.root / 'parties' or not self.workspace.is_dir():
                raise ValueError('Atelier de sauvegarde introuvable. Lance --nouvelle pour créer une partie.')
            cwd = Path(self.state.get('cwd', str(self.workspace)))
            if not cwd.is_dir() or not cwd.is_relative_to(self.workspace): cwd = self.workspace
        else:
            campaign = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            self.workspace = self.root / 'parties' / campaign
            seed(self.workspace)
            self.state = {'version': VERSION, 'workspace': str(self.workspace), 'index': 0, 'completed': [], 'hints': {}, 'points': 0, 'variables': {}}
            cwd = self.workspace
        self.shell = BashSession(self.workspace, cwd, self.state.get('variables'), exported=self.state.get('exported'))
        self.last_output = ''
        self.save()

    def paint(self, text, code='36'):
        return f'\033[{code}m{text}\033[0m' if self.color else text

    def paragraph(self, text):
        width = min(94, max(40, shutil.get_terminal_size((80,24)).columns - 4))
        for line in text.splitlines(): print(textwrap.fill(line, width=width) if line else '')

    def save(self):
        cwd, variables = self.shell.snapshot()
        self.state.update(cwd=cwd, variables=variables, exported=sorted(self.shell.exported))
        temp = self.profile.with_suffix('.tmp')
        temp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding='utf-8')
        temp.replace(self.profile)
        (self.workspace / '.orion-sauvegarde.json').write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding='utf-8')

    @property
    def mission(self): return self.missions[self.state['index']]

    def banner(self):
        print(self.paint(ART))
        print(self.paint(ROBOT, '33'))
        self.paragraph('BIP-42 : Bienvenue, humain. Orion est en panne. Je supervise. Tu travailles. Accord parfait.')
        print(f'\nAtelier réel : {self.workspace}')
        self.paragraph('Tape de vraies commandes Bash au prompt. Les commandes du jeu commencent par : (exemple : :aide). :quitter sauvegarde. Tout fonctionne hors ligne après téléchargement.')
        self.map()

    def map(self):
        print(self.paint('\n+----------- CARTE DE LA STATION ORION -----------+'))
        for n, (_, title, _, badge) in enumerate(ACTS):
            done = sum(mid in self.state['completed'] for mid in range(n*6+1,n*6+7))
            mark = 'OK' if done == 6 else '>>' if n == self.state['index']//6 else '..'
            print(f' [{mark}] {n+1}. {title} ({done}/6)')
        total = len(self.state['completed'])
        bar = '#'*(total//2) + '.'*(24-total//2)
        print(f' [{bar}] {total}/48 | {self.state["points"]} XP')

    def show(self):
        m = self.mission
        act = ACTS[(m['id']-1)//6]
        print(self.paint('\n' + '='*60))
        print(self.paint(f'SECTEUR {act[0]} | MISSION {m["id"]:02}/48 - {m["title"]}', '1;36'))
        if (m['id']-1)%6 == 0:
            print(self.paint(SCENES[(m['id']-1)//6].replace('\\n','\n'), '35'))
            self.paragraph(act[2])
        self.paragraph(m['story'])
        print(self.paint('\nOBJECTIF', '1;33')); self.paragraph(m['goal'])
        print('Repères : ' + m['concepts'])
        print('Aide : :indice | :solution | :bloc | :editer fichier | :test')
        if m['id'] in self.state['completed']: print(self.paint('Mission validée. :suivant pour poursuivre.', '32'))

    def validate(self):
        m = self.mission
        failed = check_mission(m, self.workspace, self.shell, self.last_output)
        if failed:
            print(self.paint('Encore à vérifier :', '33'))
            for label in failed: print('  [ ] ' + label)
            print('BIP-42 : Pas de panique. Même mes mises à jour ratent parfois. :indice peut aider.')
            return False
        if m['id'] not in self.state['completed']:
            hints = self.state['hints'].get(str(m['id']), 0)
            points = max(40, 100-20*hints)
            self.state['completed'].append(m['id']); self.state['points'] += points
            print(self.paint(f'\n[ MISSION ACCOMPLIE ] +{points} XP', '1;32'))
            self.paragraph(m['explanation'])
            print(self.paint('BIP-42 : ' + m['success'], '33'))
            if m['id']%6 == 0: print(self.paint('[ BADGE ] ' + ACTS[(m['id']-1)//6][3], '1;35'))
            self.save()
        print('Tape :suivant pour poursuivre, ou continue tes essais ici.')
        return True

    def hint(self, solution=False):
        m = self.mission
        level = self.state['hints'].get(str(m['id']), 0)
        if solution:
            self.state['hints'][str(m['id'])] = 3
            print(self.paint('Une solution possible (à exécuter toi-même) :', '33'))
            print(m['solution'])
            print('Pour plusieurs lignes : :bloc, colle les lignes, puis :fin seul sur sa ligne.')
        else:
            print(self.paint('Indice : ' + m['hints'][min(level,1)], '33'))
            self.state['hints'][str(m['id'])] = max(level,min(level+1,2))
        self.save()

    def finale(self):
        print(self.paint(r'''
             *      /\      *
                   /==\
                  | OR |
                  | ION|
                 /|____|\
                   /\/\
             STATION SAUVEE !
''', '1;35'))
        self.paragraph('Le chocolat coule. Les drones dansent. BIP-42 annonce avoir tout fait lui-même. Ton nom apparaît quand même au tableau des commandants.')
        self.map()
        self.paragraph('Tu as utilisé le terminal, les fichiers, les variables, les scripts, les tests, les boucles, sed, awk et construit un jeu. Tes fichiers restent dans ton atelier. :quitter sauvegarde ; --nouvelle crée une autre partie sans effacer celle-ci.')

    def command(self, line):
        if line == ':aide':
            print('''COMMANDES DU JEU
:mission      Relire l'objectif actuel
:indice       Deux niveaux d'indices (-20 XP chacun)
:solution     Voir une solution complète (mission à 40 XP minimum)
:test         Vérifier le résultat sans nouvelle commande Bash
:suivant      Passer à la mission suivante après validation
:carte        Voir les secteurs, la progression et les XP
:badges       Voir les badges obtenus
:journal      Revoir les dernières commandes de cette session
:bloc         Saisir plusieurs lignes ; terminer par :fin
:editer NOM   Ouvrir un fichier de l'atelier avec nano
:quitter      Sauvegarder et fermer le jeu
Les erreurs ne retirent aucun XP. Les indices ne retirent pas les XP déjà gagnés.
Ctrl+C interrompt une commande ; Ctrl+D quitte au prompt du jeu.
Les commandes Bash s'exécutent réellement avec ton compte. Reste dans l'atelier ; sudo n'est pas nécessaire.''')
        elif line == ':mission': self.show()
        elif line == ':carte': self.map()
        elif line == ':badges':
            for n, (_, _, _, badge) in enumerate(ACTS):
                print(('[OK] ' if all(i in self.state['completed'] for i in range(n*6+1,n*6+7)) else '[..] ') + badge)
        elif line == ':journal':
            for n, command in enumerate(self.history[-15:],1): print(f'{n:2}. {command}')
        elif line == ':indice': self.hint()
        elif line == ':solution': self.hint(True)
        elif line == ':test': self.validate()
        elif line == ':suivant':
            if self.mission['id'] not in self.state['completed']: print('BIP-42 : Termine cette mission avant de décoller. :test ou :indice !')
            elif self.state['index'] == len(self.missions)-1: self.finale()
            else:
                self.state['index'] += 1; self.last_output = ''; self.save(); self.show()
        elif line == ':quitter': return False
        elif line.startswith(':editer '):
            name = line[len(':editer '):].strip()
            cwd, _ = self.shell.snapshot()
            path = (Path(cwd)/name).resolve()
            if not path.is_relative_to(self.workspace) or not path.parent.is_dir():
                print('Choisis un fichier dans un dossier existant de ton atelier.')
            else:
                subprocess.run(['nano', str(path)])
                self.validate(); self.save()
        elif line == ':bloc':
            print('Colle ton bloc Bash. Termine par :fin seul sur sa ligne. :annuler abandonne le bloc.')
            lines=[]
            while True:
                item=input('... ')
                if item == ':annuler': return True
                if item == ':fin': break
                lines.append(item)
            self.run_bash('\n'.join(lines))
        elif line.startswith(':'): print('Commande du jeu inconnue. Tape :aide.')
        elif line.strip(): self.run_bash(line)
        return True

    def run_bash(self, code):
        self.history.append(code)
        try:
            status, self.last_output = self.shell.execute(code)
            if status: print(self.paint(f'[code de retour : {status}]', '33'))
            self.validate(); self.save()
        except (RuntimeError, TimeoutError) as error:
            print(self.paint(str(error), '33'))
            cwd = self.shell.cwd if self.shell.cwd.is_dir() and self.shell.cwd.is_relative_to(self.workspace) else self.workspace
            variables = self.shell.variables.copy()
            exported = self.shell.exported.copy()
            self.shell.close(); self.shell = BashSession(self.workspace, cwd, variables, exported=exported)
            self.paragraph('BIP-42 a rouvert un Bash. Les fichiers et la progression sont conservés ; les variables du dernier point de sauvegarde sont restaurées.')

    def loop(self):
        self.banner(); self.show()
        try:
            while True:
                try:
                    line = input(self.paint(f'ORION {self.mission["id"]:02}> ', '1;36'))
                    if not self.command(line): break
                except KeyboardInterrupt: print('\nBIP-42 : Toujours là. :quitter pour sauvegarder et partir.')
                except EOFError: break
        finally:
            self.save(); self.shell.close()
            print('\nPartie sauvegardée. BIP-42 surveille le chocolat en ton absence.')


def main():
    parser=argparse.ArgumentParser(description='Orion Académie — 48 missions pour apprendre Bash en jouant.')
    parser.add_argument('--dossier', default=str(Path.home()/'orion-academie'), help='Dossier des parties et de la sauvegarde')
    parser.add_argument('--nouvelle', action='store_true', help='Nouvelle partie ; les anciens ateliers sont conservés')
    parser.add_argument('--sans-couleur', action='store_true')
    parser.add_argument('--version', action='version', version=VERSION)
    args=parser.parse_args()
    missing=[name for name in ['bash','sed','awk','nano','chmod','cp','grep','cat','ls','readlink','ps'] if not shutil.which(name)]
    if missing: parser.exit(1,'Outils manquants : '+', '.join(missing)+'\n')
    try: Game(args.dossier, args.nouvelle, not args.sans_couleur).loop()
    except (OSError, ValueError, json.JSONDecodeError) as error: parser.exit(1, 'BIP-42 : '+str(error)+'\n')


if __name__ == '__main__': main()
