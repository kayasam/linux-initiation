# Bash — Parcours débutant

Toutes les commandes s’exécutent dans Bash sur la VM Debian, après la connexion SSH. Chaque chapitre prépare le suivant. Lis un exemple, exécute-le, vérifie son résultat, puis passe au TP.

Chaque chapitre propose aussi un **quiz de 20 questions avec réponses expliquées**. Le lien figure dans les supports du cours ; la version HTML contient le quiz en bas de page. Les quiz fonctionnent hors ligne avec les ressources fournies dans le ZIP.

| Cours | Mise en pratique |
|---|---|
| [Chapitre 01 — Le shell et son environnement](01-shell-et-environnement/01-shell-et-environnement.md) | [TP 01 — Installer la station Orion](01-shell-et-environnement/tp/tp-01-environnement.md) |
| [Chapitre 02 — Les variables](02-variables/02-variables.md) | [TP 02 — Fabriquer ton badge d'équipage](02-variables/tp/tp-02-variables.md) |
| [Chapitre 03 — Écrire son premier script](03-bases-du-scripting/03-bases-du-scripting.md) | [TP 03 — Programmer le robot d'accueil](03-bases-du-scripting/tp/tp-03-bases-du-scripting.md) |
| [Chapitre 04 — Les tests et les conditions](04-tests-et-conditions/04-tests-et-conditions.md) | [TP 04 — Contrôler le sas de la station](04-tests-et-conditions/tp/tp-04-tests-et-conditions.md) |
| [Chapitre 05 — Les boucles](05-boucles/05-boucles.md) | [TP 05 — Programmer le robot copieur](05-boucles/tp/tp-05-boucles.md) |
| [Chapitre 06 — Traiter du texte avec sed et awk](06-sed-et-awk/06-sed-et-awk.md) | [TP 06 — Préparer le ravitaillement d'Orion](06-sed-et-awk/tp/tp-06-sed-et-awk.md) |

## Pour terminer

- [Orion Académie — L’aventure interactive à télécharger](../jeu/README.md)
- [TP final — BIP-42 a perdu son boulon](../tp/final/tp-final-bip-42.md)
- [Synthèse — Rapport de mission](../tp/synthese/tp-synthese.md)
- [Bonus — Trois jeux](../tp/bonus/tp-bonus-exercices-ludiques.md)

## Organisation

Chaque dossier contient le cours Markdown, son HTML autonome et `tp/`. Les neuf corrections sont séparées et marquées `publier: false`. Les exercices restent dans `~/atelier-bash/` sur la VM. Aucune modification de service, de compte ou de fichier système n’est nécessaire.
